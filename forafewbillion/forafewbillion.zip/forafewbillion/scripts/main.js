var i =  0.01;
//var sum = 0.01;

for(var days = 1; days <= 30; days++){
//    sum += i;
    i = i * 2;
};
console.log(i);