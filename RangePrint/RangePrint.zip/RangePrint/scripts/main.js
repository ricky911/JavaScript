
function printRange() {
    for (var i = 3; i < 15; i += 3){
        console.log(i);
    };
};

printRange();