$(document).ready(function(){
    $('.box, img').click(function(){
//        $(this).css('visibility', 'hidden');
//        $(this).fadeOut();
//        $(this).css('display', 'inline-block')
        $(this).addClass('hidden');
    });
     $('button').click(function(){
//        $('.box, img').fadeIn();
//         $('.box, img').css('visibility', 'visible');
         $(this).removeClass('hidden');
         
  });
})